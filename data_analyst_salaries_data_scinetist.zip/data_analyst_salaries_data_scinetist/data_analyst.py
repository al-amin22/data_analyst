# -*- coding: utf-8 -*-
"""
Created on Sun Jul  2 13:16:49 2023

@author: ASUS
"""

# Mengimpor library-classic yang umum digunakan untuk analisis data dan visualisasi.
import numpy as np
import pandas as pd

# Mengimpor library untuk visualisasi data seperti grafik dan plot.
import matplotlib.pyplot as plt
import seaborn as sns


# Membaca file CSV dan menyimpannya dalam DataFrame df.
dataku = pd.read_csv('ds_salaries.csv', header=0)

# Menampilkan 5 baris pertama dari DataFrame.
data_teratas = dataku.head()

# Memeriksa nilai null dan nilai yang hilang dalam DataFrame.
dataku.isnull().sum()
# Menghitung jumlah nilai unik untuk setiap kolom dalam DataFrame.
dataku.nunique()

# Mengganti nilai dalam kolom 'experience_level' dengan nilai yang lebih deskriptif.
dataku['experience_level'] = dataku['experience_level'].replace({
    'SE': 'Senior',
    'EN': 'Entry level',
    'EX': 'Executive level',
    'MI': 'Mid/Intermediate level',
})

# Mengganti nilai dalam kolom 'employment_type' dengan nilai yang lebih deskriptif.
dataku['employment_type'] = dataku['employment_type'].replace({
    'FL': 'Freelancer',
    'CT': 'Contractor',
    'FT' : 'Full-time',
    'PT' : 'Part-time'
})

# Mengganti nilai dalam kolom 'company_size' dengan nilai yang lebih deskriptif.
dataku['company_size'] = dataku['company_size'].replace({
    'S': 'SMALL',
    'M': 'MEDIUM',
    'L' : 'LARGE',
})

# Mengubah tipe data kolom 'remote_ratio' menjadi string.
dataku['remote_ratio'] = dataku['remote_ratio'].astype(str)

# Mengganti nilai dalam kolom 'remote_ratio' dengan nilai yang lebih deskriptif.
dataku['remote_ratio'] = dataku['remote_ratio'].replace({
    '0': 'On-Site',
    '50': 'Half-Remote',
    '100' : 'Full-Remote',
})

# Menampilkan jumlah jenis pekerjaan yang berbeda dalam kolom 'job_title'.
print('Ada', dataku['job_title'].nunique(), 'jenis pekerjaan yang berbeda tersedia')
print(80*'*')

# Menampilkan jenis pekerjaan yang tersedia dalam kolom 'job_title'.
print('Berikut adalah jenis pekerjaan:', dataku['job_title'].unique())

# Membuat DataFrame baru (data_pekerjaan) dengan menghitung frekuensi setiap jenis pekerjaan dalam kolom 'job_title'.
data_pekerjaan = pd.DataFrame(dataku['job_title'].value_counts().reset_index())

# Mengubah nama kolom 'index' menjadi 'Role' dan kolom 'job_title' menjadi 'frequency' dalam DataFrame job_df.
data_pekerjaan.rename(columns = {'index':'Role','job_title':'frequency'}, inplace = True)

# Menampilkan DataFrame job_df.
data_pekerjaan

# Mengatur ukuran gambar plot menjadi 16x8.
plt.figure(figsize=(16,8))

# Menambahkan judul plot.
plt.title("Top 10 pekerjaan berdasarkan permintaan",fontsize=20)

# Membuat bar plot menggunakan data dari kolom 'Role' dan 'frequency' dalam DataFrame job_df.
sns.barplot(x=data_pekerjaan["Role"][:10],y=data_pekerjaan['frequency'][:10])

# Menambahkan label sumbu y.
plt.ylabel("Frekuensi",fontsize=15)

# Menambahkan label sumbu x.
plt.xlabel("Jabatan pekerjaan",fontsize=15)

# Membuat rotasi label sumbu x agar mudah dibaca.
plt.xticks(rotation=45)

# Menampilkan plot.
plt.show()

#visualisasi laba-laba
# Daftar jabatan pekerjaan
job_roles = data_pekerjaan["Role"][:10].tolist()

# Daftar frekuensi pekerjaan
frequencies = data_pekerjaan['frequency'][:10].tolist()

# Jumlah jabatan pekerjaan
num_jobs = len(job_roles)

# Menghitung sudut untuk setiap sektor
angles = np.linspace(0, 2 * np.pi, num_jobs, endpoint=False).tolist()
angles += angles[:1]  # Menambahkan sudut awal ke akhir untuk melengkapi "sirkuit" sarang laba-laba.

# Membuat plot
plt.figure(figsize=(8, 8))
ax = plt.subplot(111, polar=True)

# Mengatur posisi label
plt.xticks(angles[:-1], job_roles, fontsize=12)

# Mengatur batas skala radial
ax.set_ylim(0, max(frequencies) + 10)

# Menggambar garis radial
for freq in frequencies:
    values = [freq] * (num_jobs + 1)
    ax.plot(angles, values)

# Mengisi area dalam plot dengan warna
ax.fill(angles, frequencies + [frequencies[0]], alpha=0.25)

# Menambahkan label frekuensi
for angle, freq in zip(angles, frequencies):
    ax.text(angle, freq + 2, str(freq), ha='center', va='center', fontsize=10)

# Menambahkan judul plot
plt.title("Top 10 pekerjaan berdasarkan permintaan", fontsize=20)

# Menampilkan plot
plt.show()



# Mendefinisikan fungsi assign_broader_category untuk mengelompokkan jenis pekerjaan ke dalam kategori yang lebih luas.
def data_kategori(job_title):
    data_engineering = ["Data Engineer", "Data Analyst", "Analytics Engineer", "BI Data Analyst", "Business Data Analyst", "BI Developer", "BI Analyst", "Business Intelligence Engineer", "BI Data Engineer", "Power BI Developer"]
    data_scientist = ["Data Scientist", "Applied Scientist", "Research Scientist", "3D Computer Vision Researcher", "Deep Learning Researcher", "AI/Computer Vision Engineer"]
    machine_learning = ["Machine Learning Engineer", "ML Engineer", "Lead Machine Learning Engineer", "Principal Machine Learning Engineer"]
    data_architecture = ["Data Architect", "Big Data Architect", "Cloud Data Architect", "Principal Data Architect"]
    management = ["Data Science Manager", "Director of Data Science", "Head of Data Science", "Data Scientist Lead", "Head of Machine Learning", "Manager Data Management", "Data Analytics Manager"]
    
    if job_title in data_engineering:
        return "Data Engineering"
    elif job_title in data_scientist:
        return "Data Science"
    elif job_title in machine_learning:
        return "Machine Learning"
    elif job_title in data_architecture:
        return "Data Architecture"
    elif job_title in management:
        return "Management"
    else:
        return "Other"

# Menerapkan fungsi assign_broader_category ke kolom 'job_title' dan membuat kolom baru 'job_category'.
dataku['kategori_pekerjaan'] = dataku['job_title'].apply(data_kategori)

# Membuat DataFrame baru (job_category_df) dengan menghitung frekuensi setiap kategori pekerjaan dalam kolom 'job_category'.
data_kategori_pekerjaan = pd.DataFrame(dataku['kategori_pekerjaan'].value_counts().reset_index())

# Mengubah nama kolom 'index' menjadi 'category' dan kolom 'job_category' menjadi 'frequency' dalam DataFrame job_category_df.
data_kategori_pekerjaan.rename(columns = {'index':'kategori','kategori_pekerjaan':'frequency'}, inplace = True)

data_kategori_pekerjaan

# Membuat histogram untuk distribusi gaji.
columns = ['salary_in_usd']
for col in columns:
    sns.histplot(dataku[col], kde=True)
    (mu, sigma) = stats.norm.fit(dataku[col])
    print('{}: mu = {:.2f}, sigma = {:.2f}'.format(col, mu, sigma))
    print('{}: Skewness: {:.2f}'.format(col, dataku[col].skew()))
    print('{}: Kurtosis: {:.2f}'.format(col, dataku[col].kurt()))
    x = np.linspace(mu - 3*sigma, mu + 3*sigma, 100)
    y = stats.norm.pdf(x, mu, sigma)
    plt.plot(x, y, label='Normal fit')
    plt.xlabel(col,fontsize=15)
    plt.ylabel('Frekuensi',fontsize=15)
    plt.title('Distribusi {}'.format(col),fontsize=20)
    plt.show()

# Membuat boxplot dan swarmplot untuk kolom 'salary_in_usd'.
plt.figure(figsize=(8, 6))
sns.boxplot(x=dataku['salary_in_usd'])
sns.swarmplot(x=dataku['salary_in_usd'], color='blue', alpha=0.4, size=2.5)
plt.ylabel('Gaji dalam USD',fontsize=15)
plt.xlabel('Gaji dalam USD',fontsize=15)
plt.title('Boxplot dan Swarmplot Gaji',fontsize=20)
plt.show()

# Mengatur ukuran gambar plot menjadi 16x8.
plt.figure(figsize=(16,8))

# Menambahkan judul plot.
plt.title("Jumlah Pekerjaan Berdasarkan Kategori",fontsize=20)

# Membuat bar plot menggunakan data dari kolom 'category' dan 'frequency' dalam DataFrame job_category_df.
sns.barplot(x=data_kategori_pekerjaan["kategori"],y=data_kategori_pekerjaan['frequency'])

# Menambahkan label sumbu y.
plt.ylabel("Frekuensi",fontsize=15)

# Menambahkan label sumbu x.
plt.xlabel("Kategori",fontsize=15)

# Membuat rotasi label sumbu x agar mudah dibaca.
plt.xticks(rotation=45)

# Menampilkan plot.
plt.show()


# Membuat boxplot untuk distribusi gaji pada berbagai jenis pekerjaan.
plt.figure(figsize=(10, 6))
sns.boxplot(data=dataku, x='employment_type', y='salary_in_usd')
plt.title('Distribusi Gaji Berdasarkan Jenis Pekerjaan',fontsize=20)
plt.xlabel('Jenis Pekerjaan',fontsize=15)
plt.ylabel('Gaji dalam USD',fontsize=15)
plt.show()

# Membuat histogram untuk distribusi gaji.
columns = ['salary_in_usd']
for col in columns:
    sns.histplot(dataku[col], kde=True)
    (mu, sigma) = stats.norm.fit(dataku[col])
    print('{}: mu = {:.2f}, sigma = {:.2f}'.format(col, mu, sigma))
    print('{}: Skewness: {:.2f}'.format(col, dataku[col].skew()))
    print('{}: Kurtosis: {:.2f}'.format(col, dataku[col].kurt()))
    x = np.linspace(mu - 3*sigma, mu + 3*sigma, 100)
    y = stats.norm.pdf(x, mu, sigma)
    plt.plot(x, y, label='Normal fit')
    plt.xlabel(col,fontsize=15)
    plt.ylabel('Frekuensi',fontsize=15)
    plt.title('Distribusi {}'.format(col),fontsize=20)
    plt.show()

# Membuat boxplot dan swarmplot untuk kolom 'salary_in_usd'.
plt.figure(figsize=(8, 6))
sns.boxplot(x=dataku['salary_in_usd'])
sns.swarmplot(x=dataku['salary_in_usd'], color='blue', alpha=0.4, size=2.5)
plt.ylabel('Gaji dalam USD',fontsize=15)
plt.xlabel('Gaji dalam USD',fontsize=15)
plt.title('Boxplot dan Swarmplot Gaji',fontsize=20)
plt.show()

# Membuat pivot table yang menampilkan median gaji berdasarkan kategori pekerjaan dan tahun kerja.
pivot_table = dataku.pivot_table(values='salary_in_usd', index='kategori_pekerjaan', columns='work_year', aggfunc='median')
plt.figure(figsize=(14, 6))
sns.heatmap(pivot_table, annot=True, fmt=".2f", cmap="rocket")
plt.title('Median Gaji Berdasarkan Tahun pivot',fontsize=20)
plt.xlabel('Tahun',fontsize=15)
plt.ylabel('Kategori Pekerjaan',fontsize=15)
plt.show()

# Membuat scatter plot untuk membandingkan gaji antara tempat tinggal karyawan dan lokasi perusahaan.
plt.figure(figsize=(15, 15))
sns.scatterplot(data=dataku, x='employee_residence', y='company_location', hue='salary_in_usd', size='salary_in_usd', sizes=(20, 200), alpha=0.5)
plt.title('Perbandingan Gaji antara Tempat Tinggal Karyawan dan Lokasi Perusahaan',fontsize=20)
plt.xlabel('Tempat Tinggal Karyawan',fontsize=15)
plt.ylabel('Lokasi Perusahaan',fontsize=15)
plt.xticks(rotation=90)
plt.legend(loc='upper right', bbox_to_anchor=(1.2, 1))
plt.show()


# Membuat bar plot untuk membandingkan rata-rata gaji berdasarkan lokasi perusahaan.
rata2_gaji_by_lokasi = dataku.groupby('company_location')['salary_in_usd'].mean().sort_values(ascending=False)
plt.figure(figsize=(20, 10))
sns.barplot(x=rata2_gaji_by_lokasi.index, y=rata2_gaji_by_lokasi)
plt.title('Rata-rata Gaji berdasarkan Lokasi Perusahaan (Tahunan)',fontsize=20)
plt.xlabel('Lokasi Perusahaan',fontsize=15)
plt.ylabel('Rata-rata Gaji (Tahunan)',fontsize=15)
plt.xticks(rotation=90)
plt.show()

# Membuat bar plot untuk membandingkan rata-rata gaji berdasarkan tempat tinggal karyawan.
rata2_gaji_by_tt = dataku.groupby('employee_residence')['salary_in_usd'].mean().sort_values(ascending=False)
plt.figure(figsize=(20, 10))
sns.barplot(x=rata2_gaji_by_tt.index, y=rata2_gaji_by_tt.values)
plt.title('Rata-rata Gaji berdasarkan Tempat Tinggal Karyawan (Tahunan)',fontsize=20)
plt.xlabel('Tempat Tinggal Karyawan',fontsize=15)
plt.ylabel('Rata-rata Gaji (Tahunan)',fontsize=15)
plt.xticks(rotation=90)
plt.show()

